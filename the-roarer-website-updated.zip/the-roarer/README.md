# The Roarer — Website

A complete 7-page static website: Home, About, Services, Our Work, Websites, Apps, Contact.

## Deploy (no build needed)
1. Unzip this folder.
2. Drag the WHOLE `the-roarer` folder into https://app.netlify.com/drop
   (or upload it as-is to Hostinger / GoDaddy / any static host, or to GitHub Pages).
3. Make sure `index.html` stays at the root of whatever you upload — do not rename it.

## Structure
- index.html, about.html, services.html, work.html, websites.html, apps.html, contact.html
- /css/style.css — shared styling
- /js/main.js — shared navigation, animations, filters, lightbox, contact form
- /assets/logo — The Roarer logo
- /assets/screenshots — campaign/SEO dashboard screenshots used on work.html
- /assets/docs — downloadable CV (linked from the contact page)

## Contact form
There is no backend. Submitting the form opens the visitor's email app with a
pre-filled message to ishiiiparmar@gmail.com. To collect submissions without opening
an email app, connect the form to a service like Formspree or Netlify Forms.
