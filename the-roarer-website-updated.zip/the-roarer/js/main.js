// ---------- Preloader ----------
window.addEventListener('load', ()=>{
  const fill = document.getElementById('preloadFill');
  if(fill) requestAnimationFrame(()=>{ fill.style.width = '100%'; });
  setTimeout(()=>{
    const pl = document.getElementById('preloader');
    if(pl) pl.classList.add('hide');
    const hh = document.getElementById('heroHead');
    if(hh) hh.classList.add('reveal');
  }, 600);
});

// ---------- Hero headline word-stagger ----------
(function(){
  const el = document.getElementById('heroHead');
  if(!el) return;
  const words = el.textContent.trim().split(' ');
  el.innerHTML = words.map((w,i)=>`<span class="word" style="transition-delay:${i*55}ms"><span>${w}&nbsp;</span></span>`).join('');
})();

// ---------- Nav scroll state + progress ----------
const nav = document.getElementById('mainNav');
const progress = document.getElementById('progress');
window.addEventListener('scroll', ()=>{
  if(nav) nav.classList.toggle('scrolled', window.scrollY > 30);
  const h = document.documentElement;
  const pct = (h.scrollTop || document.body.scrollTop) / ((h.scrollHeight || document.body.scrollHeight) - h.clientHeight) * 100;
  if(progress) progress.style.width = pct + '%';
}, {passive:true});

// ---------- Mobile menu ----------
const burger = document.getElementById('burgerBtn');
const mobileMenu = document.getElementById('mobileMenu');
if(burger && mobileMenu){
  burger.addEventListener('click', ()=> mobileMenu.classList.toggle('open'));
  mobileMenu.querySelectorAll('a').forEach(a=> a.addEventListener('click', ()=> mobileMenu.classList.remove('open')));
}

// ---------- Scroll reveal ----------
const revealEls = document.querySelectorAll('.reveal-up');
const io = new IntersectionObserver((entries)=>{
  entries.forEach(e=>{ if(e.isIntersecting){ e.target.classList.add('in'); io.unobserve(e.target); } });
}, {threshold:.12});
revealEls.forEach(el=> io.observe(el));

// timeline dots
const tlItems = document.querySelectorAll('.tl-item');
const io2 = new IntersectionObserver((entries)=>{
  entries.forEach(e=>{ if(e.isIntersecting) e.target.classList.add('in'); });
}, {threshold:.4});
tlItems.forEach(el=> io2.observe(el));

// ---------- Counters ----------
const counters = document.querySelectorAll('.counter');
const io3 = new IntersectionObserver((entries)=>{
  entries.forEach(e=>{
    if(e.isIntersecting){
      const el = e.target; const target = +el.dataset.target; const suf = el.dataset.suffix || '';
      let cur = 0; const step = Math.max(1, Math.round(target/40));
      const t = setInterval(()=>{
        cur += step;
        if(cur >= target){ cur = target; clearInterval(t); }
        el.textContent = cur + suf;
      }, 30);
      io3.unobserve(el);
    }
  });
}, {threshold:.6});
counters.forEach(el=> io3.observe(el));

// ---------- Lightbox (used on work.html) ----------
let lbList = [], lbIndex = 0;
function openLightbox(list, idx){
  lbList = list; lbIndex = idx;
  updateLightbox();
  const lb = document.getElementById('lightbox');
  if(lb) lb.classList.add('open');
}
function updateLightbox(){
  const item = lbList[lbIndex];
  const img = document.getElementById('lbImg');
  const cap = document.getElementById('lbCap');
  if(img){ img.src = item.src; img.alt = item.title; }
  if(cap) cap.textContent = item.title;
}
document.addEventListener('DOMContentLoaded', ()=>{
  const lightbox = document.getElementById('lightbox');
  if(!lightbox) return;
  const close = document.getElementById('lbClose');
  const prev = document.getElementById('lbPrev');
  const next = document.getElementById('lbNext');
  if(close) close.addEventListener('click', ()=> lightbox.classList.remove('open'));
  if(prev) prev.addEventListener('click', ()=>{ lbIndex = (lbIndex-1+lbList.length)%lbList.length; updateLightbox(); });
  if(next) next.addEventListener('click', ()=>{ lbIndex = (lbIndex+1)%lbList.length; updateLightbox(); });
  lightbox.addEventListener('click', (e)=>{ if(e.target===lightbox) lightbox.classList.remove('open'); });
  document.addEventListener('keydown', (e)=>{
    if(!lightbox.classList.contains('open')) return;
    if(e.key==='Escape') lightbox.classList.remove('open');
    if(e.key==='ArrowLeft' && prev) prev.click();
    if(e.key==='ArrowRight' && next) next.click();
  });
});

// ---------- Contact form (mailto fallback, no backend) ----------
document.addEventListener('DOMContentLoaded', ()=>{
  const form = document.getElementById('enquiryForm');
  if(!form) return;
  form.addEventListener('submit', (e)=>{
    e.preventDefault();
    const name = form.name.value.trim();
    const email = form.email.value.trim();
    const company = form.company.value.trim();
    const service = form.service.value;
    const details = form.details.value.trim();
    const msgBox = document.getElementById('formMsg');
    const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if(!name || !emailRe.test(email) || !details){
      msgBox.textContent = 'Please fill in your name, a valid email, and project details.';
      msgBox.className = 'form-msg show err';
      return;
    }
    const subject = encodeURIComponent(`New enquiry from ${name} — ${service || 'General'}`);
    const body = encodeURIComponent(
      `Name: ${name}\nEmail: ${email}\nCompany/Brand: ${company}\nService Required: ${service}\n\nProject Details:\n${details}`
    );
    window.location.href = `mailto:ishiiiparmar@gmail.com?subject=${subject}&body=${body}`;
    msgBox.textContent = "Opening your email app to send this enquiry — if nothing opens, email us directly at ishiiiparmar@gmail.com.";
    msgBox.className = 'form-msg show ok';
  });
});
